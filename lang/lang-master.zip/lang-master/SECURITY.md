# Security Policy

This project is text translations of Laravel project. So, this project doesn't need to have security policy.
